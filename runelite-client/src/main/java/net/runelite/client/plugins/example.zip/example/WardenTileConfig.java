package com.example;

import net.runelite.client.config.*;

import java.awt.Color;

@ConfigGroup("wardentile")
public interface WardenTileConfig extends Config
{
    @ConfigItem(
            keyName = "showLastSafeTile",
            name = "Show Last Safe Tile",
            description = "Show the last safe tile letter on the overlay",
            position = 0
    )
    default boolean showLastSafeTile()
    {
        return true;
    }

    @ConfigItem(
            keyName = "showSiphonPhases",
            name = "Show Siphon Phase Count",
            description = "Show how many siphon phases have occurred",
            position = 1
    )
    default boolean showSiphonPhases()
    {
        return true;
    }

    @Alpha
    @ConfigItem(
            keyName = "safeColor",
            name = "Safe Tile Color",
            description = "Color used for safe tile letters",
            position = 2
    )
    default Color safeColor()
    {
        return new Color(0, 204, 51); // RS green
    }

    @Alpha
    @ConfigItem(
            keyName = "unsafeColor",
            name = "Unsafe Tile Color",
            description = "Color used for unsafe tile letters",
            position = 3
    )
    default Color unsafeColor()
    {
        return new Color(204, 0, 0); // RS red
    }

    @Alpha
    @ConfigItem(
            keyName = "textColor",
            name = "Text Color",
            description = "Color used for text labels",
            position = 4
    )
    default Color textColor()
    {
        return new Color(255, 255, 255); // white
    }

    @Alpha
    @ConfigItem(
            keyName = "borderColor",
            name = "Overlay Border Color",
            description = "Color of the overlay border",
            position = 5
    )
    default Color borderColor()
    {
        return new Color(50, 50, 50, 180); // semi-transparent dark gray
    }

    @Alpha
    @ConfigItem(
            keyName = "fillColor",
            name = "Overlay Fill Color",
            description = "Color of the overlay background",
            position = 6
    )
    default Color fillColor()
    {
        return new Color(0, 0, 0, 150); // translucent black
    }

    @ConfigItem(
            keyName = "overlayHeight",
            name = "Overlay Height",
            description = "Height of the overlay box",
            position = 7
    )
    default int overlayHeight()
    {
        return 40;
    }

    @ConfigItem(
            keyName = "overlayWidth",
            name = "Overlay Width",
            description = "Width of the overlay box",
            position = 8
    )
    default int overlayWidth()
    {
        return 160;
    }
    @ConfigItem(
            keyName = "fontSize",
            name = "Font Size",
            description = "Font size used in the overlay",
            position = 9
    )
    default int fontSize()
    {
        return 14;  // default font size
    }
}
