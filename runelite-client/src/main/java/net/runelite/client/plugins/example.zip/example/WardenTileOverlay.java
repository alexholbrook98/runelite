package com.example;

import net.runelite.api.Client;
import net.runelite.api.Point;
import net.runelite.client.ui.overlay.*;

import javax.inject.Inject;
import java.awt.*;

import static com.example.OverlayUtil.*;

public class WardenTileOverlay extends OverlayPanel
{
    private final Client client;
    private final WardenTilePlugin plugin;
    private final WardenTileConfig config;

    @Inject
    public WardenTileOverlay(Client client, WardenTilePlugin plugin, WardenTileConfig config)
    {
        super(plugin);
        this.client = client;
        this.plugin = plugin;
        this.config = config;
        setPosition(OverlayPosition.TOP_LEFT);
        setLayer(OverlayLayer.ABOVE_WIDGETS);
        setPriority(OverlayPriority.HIGH);
    }

    @Override
    public Dimension render(Graphics2D g)
    {
        final int boxX = 10;
        final int boxY = 10;
        final int boxWidth = 160;
        final int boxHeight = config.overlayHeight();

        int fontSize = config.fontSize();
        Font fontPlain = new Font("Arial", Font.PLAIN, fontSize);
        Font fontBold = new Font("Arial", Font.BOLD, fontSize);

        g.setFont(fontPlain);
        // Draw background and border manually
        drawOutlineAndFill(g, config.borderColor(), config.fillColor(), 2f, new Rectangle(boxX, boxY, boxWidth, boxHeight));

        int textY = boxY + fontSize + 5;
        int lineSpacing = fontSize + 6;

        if (config.showLastSafeTile())
        {
            renderTextLocation(g, new Point(boxX + 5, textY), "Last Safe Tile:", config.textColor(), fontSize, Font.PLAIN, true);

            String[] tiles = {"R", "L", "M"};
            int baseX = boxX + 110;

            for (int i = 0; i < tiles.length; i++)
            {
                String tile = tiles[i];
                Color color = config.unsafeColor();

                boolean siphonActive = plugin.getSiphonCount() > 0;

                if (siphonActive)
                {
                    if (tile.equals(plugin.getLockedSafeTileLetter()))
                    {
                        color = config.safeColor();
                    }
                }
                else
                {
                    if (tile.equals(plugin.getCurrentSafeTileLetter()))
                    {
                        color = config.safeColor();
                    }
                }

                renderTextLocation(g, new Point(baseX + i * (fontSize + 6), textY), tile, color, fontSize, Font.BOLD, true);
            }
        }

        if (config.showSiphonPhases())
        {
            textY += lineSpacing;
            renderTextLocation(
                    g,
                    new Point(boxX + 5, textY),
                    "Siphon Phases: " + plugin.getSiphonCount() + "/4",
                    config.textColor(),
                    fontSize,
                    Font.PLAIN,
                    true
            );
        }

        return new Dimension(boxWidth, boxHeight);
    }
}
