# Warden Tile Tracker

A RuneLite plugin to assist players in the Tumeken’s Warden fight by tracking the safe tile during siphon phases.

## Overview

During the Tumeken’s Warden boss fight, players must avoid dangerous floor tiles during the siphon phases. This plugin tracks the last safe tile before each siphon phase and displays it clearly in an unobtrusive overlay on the RuneLite client.

## Features

- Detects the safe tile based on Tumeken’s Warden animations.
- Displays the safe tile as a letter: **M** (Middle), **R** (Right), or **L** (Left) in a top-left corner overlay.
- Highlights the letter corresponding to the safe tile in green for quick visual identification.
- Tracks and displays the siphon phase count.
- Logs safe tile data and siphon phases to a file for review.

## Important Compliance Notes

- **No in-world tile highlighting or overlays:** The plugin does *not* mark or highlight tiles on the game screen itself.
- **Overlay-only information display:** The safe tile is shown as a simple letter in the UI overlay — no direct game world indication.
- **Rule adherence:** This design ensures full compliance with RuneLite and Jagex plugin guidelines by avoiding any information that might give an unfair advantage or breach game rules.
- **Transparency:** All data shown is derived strictly from in-game NPC animations and events, ensuring fair gameplay.

## Installation

1. Clone or download this repository.
2. Build the plugin using Maven/Gradle according to RuneLite plugin development guidelines.
3. Add the compiled plugin JAR to your RuneLite sideloaded plugins folder.
4. Enable the plugin in RuneLite’s plugin manager.

## How to Use

- Launch the Tumeken’s Warden fight.
- The overlay will automatically update showing the safe tile letter and siphon phase count during each phase.
- Use this information to avoid the dangerous floor tiles during siphon phases.

## Development and Contribution

Contributions and improvements are welcome. Please ensure any changes maintain compliance with RuneLite and Jagex policies.

## License

This plugin is open source under the MIT License.