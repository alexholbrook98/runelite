package com.example;

import com.google.inject.Provides;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import net.runelite.api.*;
import net.runelite.api.events.GameTick;
import net.runelite.client.chat.ChatMessageManager;
import net.runelite.client.chat.QueuedMessage;
import net.runelite.client.config.ConfigManager;
import net.runelite.client.eventbus.Subscribe;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.plugins.PluginDescriptor;
import net.runelite.client.ui.overlay.OverlayManager;
import net.runelite.client.util.ColorUtil;

import javax.inject.Inject;
import java.awt.Color;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Slf4j
@PluginDescriptor(
        name = "Warden Tile Tracker"
)
public class WardenTilePlugin extends Plugin
{
    @Inject private Client client;
    @Inject private OverlayManager overlayManager;
    @Inject private WardenTileOverlay overlay;
    @Inject private WardenTileConfig config;
    @Inject private ChatMessageManager chatMessageManager;

    private static final DateTimeFormatter TIMESTAMP_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    // Warden animation IDs
    private static final int SAFE_RIGHT_ANIM = 9675;
    private static final int SAFE_LEFT_ANIM = 9677;
    private static final int SAFE_CENTER_ANIM = 9679;
    private static final int SIPHON_START_ANIM = 9682;

    @Getter private String lockedSafeTileLetter = "?";
    @Getter private int siphonCount = 0;
    @Getter private String currentSafeTileLetter = "?";

    private boolean inSiphonPhase = false;
    private BufferedWriter logWriter;

    @Provides
    WardenTileConfig provideConfig(ConfigManager configManager)
    {
        return configManager.getConfig(WardenTileConfig.class);
    }

    @Override
    protected void startUp()
    {
        overlayManager.add(overlay);
        siphonCount = 0;
        lockedSafeTileLetter = "?";
        currentSafeTileLetter = "?";
        inSiphonPhase = false;
        setupLogFile();
        logInfo("Warden Tile Tracker started");
    }

    @Override
    protected void shutDown()
    {
        overlayManager.remove(overlay);
        closeLogFile();
        logInfo("Warden Tile Tracker stopped");
    }

    private void setupLogFile()
    {
        try
        {
            File desktop = new File(System.getProperty("user.home"), "Desktop");
            File logFile = new File(desktop, "warden_tile_log.txt");
            logWriter = new BufferedWriter(new FileWriter(logFile, true));
            logInfo("=== Logging Started at " + LocalDateTime.now().format(TIMESTAMP_FORMATTER) + " ===");
        }
        catch (IOException e)
        {
            log.warn("Failed to create log file", e);
        }
    }

    private void closeLogFile()
    {
        if (logWriter != null)
        {
            try
            {
                logInfo("=== Logging Ended at " + LocalDateTime.now().format(TIMESTAMP_FORMATTER) + " ===");
                logWriter.close();
            }
            catch (IOException e)
            {
                log.warn("Failed to close log file", e);
            }
        }
    }

    private void logInfo(String message)
    {
        log.info(message);
        if (chatMessageManager != null)
        {
            chatMessageManager.queue(QueuedMessage.builder()
                    .type(ChatMessageType.GAMEMESSAGE)
                    .runeLiteFormattedMessage(ColorUtil.wrapWithColorTag("[WardenTile] ", Color.CYAN) + message)
                    .build());
        }
        if (logWriter != null)
        {
            try
            {
                logWriter.write(LocalDateTime.now().format(TIMESTAMP_FORMATTER) + " - " + message + "\n");
                logWriter.flush();
            }
            catch (IOException e)
            {
                log.warn("Failed to write to log file", e);
            }
        }
    }

    @Subscribe
    public void onGameTick(GameTick event)
    {
        for (NPC npc : client.getNpcs())
        {
            if (npc == null || !"Tumeken's Warden".equalsIgnoreCase(npc.getName()))
                continue;

            int anim = npc.getAnimation();

            if (anim == SIPHON_START_ANIM)
            {
                if (!inSiphonPhase)
                {
                    inSiphonPhase = true;
                    siphonCount++;
                    lockedSafeTileLetter = currentSafeTileLetter;
                    logInfo("Siphon phase started. Locked safe tile: " + lockedSafeTileLetter + ". Siphon count: " + siphonCount);
                }
                return;
            }

            if (inSiphonPhase && (anim == SAFE_RIGHT_ANIM || anim == SAFE_LEFT_ANIM || anim == SAFE_CENTER_ANIM))
            {
                // Siphon has ended
                inSiphonPhase = false;
                logInfo("Siphon phase ended.");
            }

            if (!inSiphonPhase)
            {
                switch (anim)
                {
                    case SAFE_RIGHT_ANIM:
                        if (!"R".equals(currentSafeTileLetter))
                        {
                            currentSafeTileLetter = "R";
                            logInfo("Safe tile detected (before siphon): RIGHT");
                        }
                        break;
                    case SAFE_LEFT_ANIM:
                        if (!"L".equals(currentSafeTileLetter))
                        {
                            currentSafeTileLetter = "L";
                            logInfo("Safe tile detected (before siphon): LEFT");
                        }
                        break;
                    case SAFE_CENTER_ANIM:
                        if (!"M".equals(currentSafeTileLetter))
                        {
                            currentSafeTileLetter = "M";
                            logInfo("Safe tile detected (before siphon): MIDDLE");
                        }
                        break;
                }
            }
        }
    }
}
